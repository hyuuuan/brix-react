const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const { toManilaISO } = require('../utils/dateUtils');

// Heartbeat endpoint to maintain session activity
router.get('/heartbeat', auth, async (req, res) => {
    try {
        console.log('💓 Heartbeat request from:', req.user.username);
        
        // Simply respond with current user info to confirm session is active
        res.json({
            success: true,
            message: 'Session active',
            data: {
                user: {
                    employee_id: req.user.employee_id,
                    username: req.user.username,
                    full_name: req.user.first_name + ' ' + req.user.last_name,
                    role: req.user.role
                },
                timestamp: toManilaISO(),
                session_status: 'active'
            }
        });
        
    } catch (error) {
        console.error('❌ Heartbeat error:', error);
        res.status(500).json({
            success: false,
            message: 'Heartbeat failed',
            error: error.message
        });
    }
});

module.exports = router;
